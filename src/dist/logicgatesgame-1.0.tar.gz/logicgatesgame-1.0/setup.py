from setuptools import setup

setup(
    name="LogicGatesGame",
    version="1.0",
    packages=["control"],
    install_requires=[
        "PySide6",
        
    ],
    entry_points={
        "console_scripts": [
            "logicgates = main.py:main_function",
        ],
    },
)
